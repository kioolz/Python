saldo = 1000
limite = 1000

print(saldo is limite)
print(saldo is not limite)
